import unittest
from pathlib import Path

import advanced_evaluation as ae
import app as application_module
from tests.test_application_flow import ApplicationFlowTests

CRITERIA = [
    {"criterion": "Technical Feasibility", "description": "", "maximum_score": 10, "weight": 60, "required": True},
    {"criterion": "Expected Impact", "description": "", "maximum_score": 10, "weight": 40, "required": True},
]
CONFIG = ae.normalize_config({})


def card(name, technical, impact, recused=False):
    return {
        "panelistName": name,
        "recused": recused,
        "scores": {} if recused else {"Technical Feasibility": technical, "Expected Impact": impact},
    }


class EngineTests(unittest.TestCase):
    def test_config_rejects_weights_that_do_not_sum_to_100_or_let_price_dominate(self):
        with self.assertRaises(ValueError):
            ae.normalize_config({"technicalWeight": 70, "financialWeight": 20})
        with self.assertRaises(ValueError):
            ae.normalize_config({"technicalWeight": 40, "financialWeight": 60})
        self.assertEqual(ae.normalize_config({"technicalWeight": 80, "financialWeight": 20})["technicalWeight"], 80)

    def test_pre_assessment_flags_missing_requirements_and_unquantified_impact(self):
        challenge = {"difficulty": "Advanced", "requirements": {"mandatory": ["Role-based access for authorized users", "Offline data synchronisation"]}}
        answers = {"solution_description": "We provide role based access control so authorized users can log in.", "development_stage": "Idea stage", "measurable_impact": "Better outcomes"}
        result = ae.pre_assessment(challenge, answers)
        statuses = {item["requirement"]: item["status"] for item in result["coverage_items"]}
        self.assertEqual(statuses["Role-based access for authorized users"], "covered")
        self.assertEqual(statuses["Offline data synchronisation"], "missing")
        messages = " ".join(flag["message"] for flag in result["flags"])
        self.assertIn("not addressed", messages)
        self.assertIn("quantified", messages)
        self.assertIn("concept stage", messages)
        self.assertEqual(result["readiness"]["label"], "Concept")

    def test_readiness_prefers_most_mature_stage_mentioned(self):
        self.assertEqual(ae.readiness_level("Prototype complete, now in pilot with two districts")["label"], "Pilot")
        self.assertEqual(ae.readiness_level("Deployed in production")["level"], 4)

    def test_trimmed_mean_drops_outliers_and_flags_divergence(self):
        cards = [card("A", 8, 7), card("B", 8, 7), card("C", 7, 7), card("D", 1, 7)]
        panel = ae.aggregate_panel(CRITERIA, cards, CONFIG)
        technical = panel["criteria"][0]
        self.assertEqual(technical["aggregated"], 7.5)  # 1 and 8 dropped
        self.assertTrue(technical["divergent"])  # spread 70% > 25%
        self.assertEqual(panel["confidence"], "Medium")
        self.assertEqual(panel["technical_score"], round((7.5 / 10 * 60 + 7 / 10 * 40), 2))
        strict = next(item for item in panel["calibration"] if item["panelistName"] == "D")
        self.assertEqual(strict["tendency"], "Strict")

    def test_recused_panelist_is_excluded_and_moderation_overrides(self):
        cards = [card("A", 9, 6), card("B", 3, 6), card("Conflicted", 10, 10, recused=True)]
        moderation = {"Technical Feasibility": {"score": 6, "note": "Agreed after discussion"}}
        panel = ae.aggregate_panel(CRITERIA, cards, CONFIG, moderation)
        self.assertEqual(panel["panel_size"], 2)
        self.assertEqual(panel["recused"], ["Conflicted"])
        self.assertEqual(panel["criteria"][0]["final"], 6)
        self.assertEqual(panel["divergent_criteria"], [])
        self.assertEqual(panel["confidence"], "Low")  # below minimum panel of 3

    def test_scorecard_requires_conflict_declaration_and_required_scores(self):
        with self.assertRaises(ValueError):
            ae.validate_scorecard(CRITERIA, {"panelistName": "A", "scores": {"Technical Feasibility": 5, "Expected Impact": 5}})
        with self.assertRaises(ValueError):
            ae.validate_scorecard(CRITERIA, {"panelistName": "A", "conflictOfInterest": "none", "scores": {"Technical Feasibility": 5}})
        with self.assertRaises(ValueError):
            ae.validate_scorecard(CRITERIA, {"panelistName": "A", "conflictOfInterest": "none", "scores": {"Technical Feasibility": 11, "Expected Impact": 5}})
        recused = ae.validate_scorecard(CRITERIA, {"panelistName": "A B", "conflictOfInterest": "declared", "conflictNote": "Former advisor"})
        self.assertTrue(recused["recused"])
        self.assertEqual(recused["panelistId"], "a-b")

    def test_risk_requires_mitigation_for_high_risks_and_computes_penalty(self):
        risks = {key: {"likelihood": 2, "impact": 2} for key in ae.RISK_KEYS}
        risks["technical"] = {"likelihood": 4, "impact": 4}
        with self.assertRaises(ValueError):
            ae.validate_risk({"risks": risks})
        risks["technical"]["mitigation"] = "Staged delivery with acceptance gates"
        profile = ae.risk_profile(ae.validate_risk({"risks": risks}), CONFIG)
        self.assertEqual(profile["level"], "Critical")
        expected_index = (16 + 4 * 5) / (25 * 6) * 100
        self.assertEqual(profile["index"], round(expected_index, 1))
        self.assertAlmostEqual(profile["penalty_pct"], round(expected_index / 100 * 10, 2))

    def _entry(self, application_id, technical, quote=None, penalty=0.0, confidence="High", risk="Low"):
        return {"application_id": application_id, "startup_name": application_id, "technical_score": technical, "quote": quote,
                "risk_penalty_pct": penalty, "confidence": confidence, "risk_level": risk}

    def test_qcbs_ranks_threshold_qualified_bids_and_detects_sensitivity(self):
        entries = [
            self._entry("A", 90, quote=1_000_000),
            self._entry("B", 72, quote=600_000),
            self._entry("C", 55, quote=100_000),  # below threshold: price must not rescue it
        ]
        result = ae.rank_applications(entries, CONFIG, maximum_selected=1)
        by_id = {item["application_id"]: item for item in result["applications"]}
        self.assertTrue(result["financial_applied"])
        self.assertIsNone(by_id["C"]["rank"])
        self.assertEqual(by_id["C"]["recommendation"], "Below technical threshold")
        self.assertEqual(by_id["B"]["financial_score"], 100.0)
        self.assertEqual(by_id["A"]["financial_score"], 60.0)
        # A: 0.7*90 + 0.3*60 = 81 ; B: 0.7*72 + 0.3*100 = 80.4
        self.assertEqual(by_id["A"]["rank"], 1)
        self.assertEqual(by_id["A"]["recommendation"], "Recommend")
        self.assertEqual(by_id["B"]["recommendation"], "Reserve list")
        self.assertFalse(result["leader_is_robust"])  # at 60/40 B overtakes A

    def test_financial_score_skipped_when_any_qualified_bid_missing(self):
        result = ae.rank_applications([self._entry("A", 80, quote=500), self._entry("B", 85)], CONFIG)
        self.assertFalse(result["financial_applied"])
        self.assertEqual(result["leader"], "B")

    def test_risk_penalty_and_holds_affect_recommendation(self):
        entries = [self._entry("A", 90, penalty=10, risk="Critical"), self._entry("B", 85, confidence="Low")]
        result = ae.rank_applications(entries, CONFIG)
        by_id = {item["application_id"]: item for item in result["applications"]}
        self.assertEqual(by_id["A"]["risk_adjusted_score"], 81.0)
        self.assertEqual(by_id["B"]["rank"], 1)
        self.assertEqual(by_id["A"]["recommendation"], "Hold: critical risk")
        self.assertEqual(by_id["B"]["recommendation"], "Hold: panel too small")


class AdvancedEvaluationRouteTests(ApplicationFlowTests):
    def setUp(self):
        super().setUp()
        original = application_module.ADVANCED_EVALUATION_STORE_PATH
        application_module.ADVANCED_EVALUATION_STORE_PATH = Path(self.temporary_directory.name) / "advanced.json"
        self.addCleanup(setattr, application_module, "ADVANCED_EVALUATION_STORE_PATH", original)

    def _eligible(self):
        challenge, application = self._submitted_application()
        self.assertEqual(self._screen_application(application["application_id"], challenge, "eligible").status_code, 200)
        return challenge, application

    def _scorecard(self, name, technical, impact, conflict="none"):
        return {"panelistName": name, "panelistRole": "Expert", "conflictOfInterest": conflict, "conflictNote": "Advisor" if conflict == "declared" else "",
                "scores": {"Technical Feasibility": technical, "Expected Impact": impact}}

    def test_advanced_panel_scoring_ranks_eligible_application(self):
        challenge, application = self._eligible()
        ministry = self._ministry_client()
        base = f"/api/government/applications/{application['application_id']}/advanced-evaluation"
        for name, technical in (("Asha", 80), ("Ravi", 70), ("Meera", 75)):
            self.assertEqual(ministry.post(f"{base}/panel", json=self._scorecard(name, technical, 60)).status_code, 200)
        recused = ministry.post(f"{base}/panel", json=self._scorecard("Kiran", 100, 100, conflict="declared"))
        self.assertEqual(recused.status_code, 200)
        detail = ministry.get(base).get_json()
        self.assertEqual(detail["panel"]["panel_size"], 3)
        self.assertEqual(detail["panel"]["confidence"], "High")
        self.assertEqual(detail["panel"]["technical_score"], 69.0)  # 0.6*75 + 0.4*60
        board = ministry.get(f"/api/government/challenges/{challenge['challengeId']}/advanced-evaluation").get_json()
        self.assertEqual(board["leader"], application["application_id"])
        self.assertEqual(board["applications"][0]["recommendation"], "Hold: risk not assessed")
        risks = {key: {"likelihood": 2, "impact": 2} for key in ae.RISK_KEYS}
        self.assertEqual(ministry.post(f"{base}/risk", json={"risks": risks}).status_code, 200)
        board = ministry.get(f"/api/government/challenges/{challenge['challengeId']}/advanced-evaluation").get_json()
        self.assertEqual(board["applications"][0]["recommendation"], "Recommend")
        page = ministry.get(f"/government-dashboard/{challenge['challengeId']}/advanced-evaluation")
        self.assertEqual(page.status_code, 200)
        self.assertIn(b"ranks first", page.data)
        workspace = ministry.get(f"/government-applications/{application['application_id']}/advanced-evaluation")
        self.assertEqual(workspace.status_code, 200)
        self.assertIn(b"Recused", workspace.data)

    def test_advanced_moderation_must_stay_within_panel_range(self):
        _challenge, application = self._eligible()
        ministry = self._ministry_client()
        base = f"/api/government/applications/{application['application_id']}/advanced-evaluation"
        ministry.post(f"{base}/panel", json=self._scorecard("Asha", 90, 60))
        ministry.post(f"{base}/panel", json=self._scorecard("Ravi", 30, 60))
        outside = ministry.post(f"{base}/moderation", json={"criterion": "Technical Feasibility", "score": 95, "note": "x"})
        self.assertEqual(outside.status_code, 400)
        agreed = ministry.post(f"{base}/moderation", json={"criterion": "Technical Feasibility", "score": 70, "note": "Consensus meeting"})
        self.assertEqual(agreed.status_code, 200)
        self.assertEqual(agreed.get_json()["panel"]["divergent_criteria"], [])

    def test_advanced_evaluation_blocked_before_eligibility_and_for_startups(self):
        _challenge, application = self._submitted_application()
        base = f"/api/government/applications/{application['application_id']}/advanced-evaluation"
        self.assertEqual(self._ministry_client().post(f"{base}/panel", json=self._scorecard("Asha", 80, 60)).status_code, 409)
        self.assertEqual(self._startup_client().get(base).status_code, 401)
        self.assertEqual(self._ministry_client("other-ministry").get(base).status_code, 403)

    def test_advanced_rule_change_after_scoring_requires_reason(self):
        challenge, application = self._eligible()
        ministry = self._ministry_client()
        ministry.post(f"/api/government/applications/{application['application_id']}/advanced-evaluation/panel", json=self._scorecard("Asha", 80, 60))
        url = f"/api/government/challenges/{challenge['challengeId']}/advanced-evaluation/config"
        changed = {"technicalWeight": 80, "financialWeight": 20}
        self.assertEqual(ministry.post(url, json={"config": changed}).status_code, 400)
        self.assertEqual(ministry.post(url, json={"config": changed, "reason": "Committee revised weighting"}).status_code, 200)

    def test_advanced_risk_and_financial_inputs_are_saved_and_audited(self):
        _challenge, application = self._eligible()
        ministry = self._ministry_client()
        base = f"/api/government/applications/{application['application_id']}/advanced-evaluation"
        risks = {key: {"likelihood": 2, "impact": 2} for key in ae.RISK_KEYS}
        self.assertEqual(ministry.post(f"{base}/risk", json={"risks": risks}).status_code, 200)
        self.assertEqual(ministry.post(f"{base}/financial", json={"amount": 0, "source": "bid"}).status_code, 400)
        self.assertEqual(ministry.post(f"{base}/financial", json={"amount": 450000, "source": "Sealed bid"}).status_code, 200)
        detail = ministry.get(base).get_json()
        self.assertEqual(detail["quote"], 450000)
        self.assertEqual({event["event_type"] for event in detail["history"]}, {"risk_assessed", "financial_proposal_recorded"})

    def test_advanced_evaluation_locks_after_final_selection(self):
        _challenge, application = self._eligible()
        self.final_selections[application["challenge_id"]] = {"selection_id": "SEL-1"}
        self.final_selection_audit[application["challenge_id"]] = []
        response = self._ministry_client().post(
            f"/api/government/applications/{application['application_id']}/advanced-evaluation/panel", json=self._scorecard("Asha", 80, 60)
        )
        self.assertEqual(response.status_code, 409)
        self.assertIn("locked", response.get_json()["message"])


def load_tests(loader, tests, pattern):
    """Run only this module's tests, not the inherited ApplicationFlowTests again."""
    suite = unittest.TestSuite()
    suite.addTests(loader.loadTestsFromTestCase(EngineTests))
    for name in loader.getTestCaseNames(AdvancedEvaluationRouteTests):
        if name.startswith("test_advanced"):
            suite.addTest(AdvancedEvaluationRouteTests(name))
    return suite
