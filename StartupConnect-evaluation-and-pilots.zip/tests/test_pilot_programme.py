import copy
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch

import app as application_module
import pilot_engine as pe
from tests.test_application_flow import ApplicationFlowTests

TODAY = date(2026, 10, 15)


def agreement(**overrides):
    base = {
        "mode": "Pilot",
        "scope": "Grievance triage in four wards",
        "sites": "Wards 12-15",
        "cohortSize": 400,
        "startDate": "2026-09-01",
        "endDate": "2026-12-01",
        "reportingCadence": "Biweekly",
        "budget": 1000000,
        "kpis": [
            {"kpiId": "KPI-1", "name": "Resolution time", "unit": "hours", "baseline": 72, "target": 24, "direction": "decrease", "weight": 60, "critical": True, "guardrail": 96},
            {"kpiId": "KPI-2", "name": "Citizen satisfaction", "unit": "%", "baseline": 50, "target": 80, "direction": "increase", "weight": 40},
        ],
        "milestones": [
            {"milestoneId": "MS-1", "title": "Onboarding", "dueDate": "2026-09-20", "deliverables": "Deployed", "paymentPct": 30},
            {"milestoneId": "MS-2", "title": "Mid review", "dueDate": "2026-10-30", "deliverables": "Interim report", "paymentPct": 40},
            {"milestoneId": "MS-3", "title": "Final", "dueDate": "2026-12-01", "deliverables": "Final report", "paymentPct": 30},
        ],
        "dataResponsibilities": "Department owns data",
        "ipOwnership": "Startup retains IP; government gets perpetual licence",
        "securityRequirements": "CERT-In empanelled audit",
        "exitCriteria": "Two critical incidents",
    }
    base.update(overrides)
    return base


def live_pilot(measurements=(), incidents=(), milestone_states=None, reports=None):
    return {
        "stage": "active",
        "agreement": pe.validate_agreement(agreement()),
        "wentLiveAt": "2026-09-01T09:00:00Z",
        "measurements": [{"status": "verified", "recordedAt": "", **item} for item in measurements],
        "incidents": list(incidents),
        "milestoneStates": milestone_states or {},
        "reports": reports if reports is not None else [{"submittedAt": "2026-10-10T10:00:00Z"}],
        "payments": [],
    }


class PilotEngineTests(unittest.TestCase):
    def test_agreement_validation_rules(self):
        self.assertEqual(pe.validate_agreement(agreement())["milestones"][0]["milestoneId"], "MS-1")
        broken = {
            "weights": agreement(kpis=[{**agreement()["kpis"][0], "weight": 50}]),
            "direction": agreement(kpis=[{**agreement()["kpis"][0], "target": 90, "weight": 100}]),
            "guardrail": agreement(kpis=[{**agreement()["kpis"][0], "guardrail": 30, "weight": 100}]),
            "payments": agreement(milestones=agreement()["milestones"][:2]),
            "due date": agreement(milestones=[{**agreement()["milestones"][0], "dueDate": "2027-01-01", "paymentPct": 100}]),
            "dates": agreement(endDate="2026-08-01"),
        }
        for name, raw in broken.items():
            with self.subTest(name), self.assertRaises(ValueError):
                pe.validate_agreement(raw)

    def test_readiness_items_depend_on_mode(self):
        self.assertEqual(len(pe.readiness_items("Sandbox")), 4)
        self.assertIn("Citizen feedback and grievance channel live", [item["label"] for item in pe.readiness_items("Pilot")])

    def test_kpi_forecast_for_lower_is_better_metric(self):
        kpi = pe.validate_agreement(agreement())["kpis"][0]
        readings = [
            {"kpiId": "KPI-1", "value": 60, "date": "2026-09-10", "status": "verified"},
            {"kpiId": "KPI-1", "value": 48, "date": "2026-10-10", "status": "verified"},
            {"kpiId": "KPI-1", "value": 10, "date": "2026-10-11", "status": "pending"},
        ]
        result = pe.kpi_analysis(kpi, readings, date(2026, 12, 1))
        self.assertEqual(result["latest"], 48)
        self.assertEqual(result["attainment"], 0.5)  # 72 -> 48 of 72 -> 24
        self.assertEqual(result["trend"], "Improving")
        self.assertEqual(result["pending"], 1)
        self.assertLess(result["projected"], 30)
        self.assertEqual(result["target_eta"], "2026-12-09")  # 0.4 hours/day improvement

    def test_guardrail_breach_and_critical_incident_force_red(self):
        pilot = live_pilot(measurements=[{"kpiId": "KPI-1", "value": 100, "date": "2026-10-01"}])
        health = pe.programme_health(pilot, TODAY)
        self.assertEqual(health["rag"], "Red")
        self.assertTrue(health["suspension_recommended"])
        pilot = live_pilot(incidents=[{"severity": "Critical", "status": "open"}])
        self.assertTrue(pe.programme_health(pilot, TODAY)["suspension_recommended"])

    def test_overdue_report_and_milestone_lower_health(self):
        stale = live_pilot(reports=[{"submittedAt": "2026-09-05T10:00:00Z"}])
        fresh = live_pilot()
        self.assertLess(pe.programme_health(stale, TODAY)["score"], pe.programme_health(fresh, TODAY)["score"])
        reasons = " ".join(pe.programme_health(stale, TODAY)["reasons"])
        self.assertIn("Progress report overdue", reasons)
        self.assertIn("Onboarding", reasons)  # MS-1 due 2026-09-20 and not verified

    def test_scorecard_recommends_scale_extend_close(self):
        verified_all = {key: {"status": "verified", "verifiedAt": "2026-09-19T00:00:00Z"} for key in ("MS-1", "MS-2", "MS-3")}
        strong = live_pilot(
            measurements=[{"kpiId": "KPI-1", "value": 24, "date": "2026-10-10"}, {"kpiId": "KPI-2", "value": 78, "date": "2026-10-10"}],
            milestone_states=verified_all,
        )
        self.assertEqual(pe.results_scorecard(strong, TODAY)["recommendation"], "scale")
        partial = live_pilot(measurements=[{"kpiId": "KPI-1", "value": 40, "date": "2026-10-10"}, {"kpiId": "KPI-2", "value": 70, "date": "2026-10-10"}])
        card = pe.results_scorecard(partial, TODAY)
        self.assertEqual(card["recommendation"], "extend")
        self.assertIn("Resolution time", card["critical_unmet"])
        weak = live_pilot(measurements=[{"kpiId": "KPI-1", "value": 70, "date": "2026-10-10"}])
        self.assertEqual(pe.results_scorecard(weak, TODAY)["recommendation"], "close")

    def test_one_overachieving_kpi_cannot_mask_another(self):
        pilot = live_pilot(measurements=[{"kpiId": "KPI-2", "value": 200, "date": "2026-10-10"}])
        self.assertEqual(pe.results_scorecard(pilot, TODAY)["attainment_pct"], 40.0)

    def test_report_validation(self):
        valid = pe.validate_agreement(agreement())
        with self.assertRaises(ValueError):
            pe.validate_report(valid, {}, {"summary": "x", "measurements": [{"kpiId": "KPI-1", "value": 50, "date": "2026-11-01", "evidence": "log"}]}, TODAY)
        with self.assertRaises(ValueError):
            pe.validate_report(valid, {"MS-1": {"status": "verified"}}, {"summary": "x", "milestoneClaims": [{"milestoneId": "MS-1", "evidence": "done"}]}, TODAY)
        with self.assertRaises(ValueError):
            pe.validate_report(valid, {}, {"summary": "Nothing to add"}, TODAY)


class PilotRouteTests(ApplicationFlowTests):
    def setUp(self):
        super().setUp()
        original = application_module.PILOT_STORE_PATH
        application_module.PILOT_STORE_PATH = Path(self.temporary_directory.name) / "pilots.json"
        self.addCleanup(setattr, application_module, "PILOT_STORE_PATH", original)
        today_patch = patch.object(application_module, "_today", return_value=TODAY)
        today_patch.start()
        self.addCleanup(today_patch.stop)

    def _selected(self):
        challenge, selected, remaining = self._shortlisted_pair()
        payload = {
            "selected_application_ids": [selected["application_id"]],
            "reason": "Best fit.",
            "comments_by_application": {selected["application_id"]: "Selected.", remaining["application_id"]: "Not selected."},
        }
        self.assertEqual(self._ministry_client().post(f"/api/government/challenges/{challenge['challengeId']}/final-selection/confirm", json=payload).status_code, 200)
        return challenge, selected, remaining

    def test_pilot_needs_confirmed_final_selection_and_selected_startup(self):
        challenge, selected, remaining = self._shortlisted_pair()
        url = f"/api/government/challenges/{challenge['challengeId']}/pilots"
        ministry = self._ministry_client()
        self.assertEqual(ministry.post(url, json={"applicationId": selected["application_id"]}).status_code, 409)
        payload = {"selected_application_ids": [selected["application_id"]], "reason": "Best fit.",
                   "comments_by_application": {selected["application_id"]: "Yes.", remaining["application_id"]: "No."}}
        ministry.post(f"/api/government/challenges/{challenge['challengeId']}/final-selection/confirm", json=payload)
        self.assertEqual(ministry.post(url, json={"applicationId": remaining["application_id"]}).status_code, 400)
        self.assertEqual(ministry.post(url, json={"applicationId": selected["application_id"]}).status_code, 201)
        self.assertEqual(ministry.post(url, json={"applicationId": selected["application_id"]}).status_code, 409)
        self.assertEqual(self._ministry_client("other").get(f"/api/government/pilots/PLT-{selected['application_id']}").status_code, 403)

    def test_full_pilot_lifecycle(self):
        challenge, selected, _remaining = self._selected()
        ministry, startup, other = self._ministry_client(), self._startup_client("startup-001"), self._startup_client("startup-002")
        created = ministry.post(f"/api/government/challenges/{challenge['challengeId']}/pilots", json={"applicationId": selected["application_id"]})
        pilot_id = created.get_json()["pilotId"]
        gov = f"/api/government/pilots/{pilot_id}"
        mine = f"/api/startup/pilots/{pilot_id}"
        self.assertEqual(ministry.get(f"/government-dashboard/{challenge['challengeId']}/pilots").status_code, 200)
        self.assertEqual(ministry.get(f"/government-pilots/{pilot_id}").status_code, 200)

        # Agreement: invalid, then valid; startup cannot see draft
        self.assertEqual(startup.get(mine).status_code, 404)
        bad = copy.deepcopy(agreement()); bad["kpis"][0]["weight"] = 10
        self.assertEqual(ministry.post(f"{gov}/agreement/send", json={"agreement": bad}).status_code, 400)
        self.assertEqual(ministry.post(f"{gov}/agreement/send", json={"agreement": agreement()}).status_code, 200)
        self.assertEqual(other.get(mine).status_code, 404)
        self.assertEqual(startup.get(f"/startup/pilots/{pilot_id}").status_code, 200)

        # Change request round trip, then acceptance of version 2
        self.assertEqual(startup.post(f"{mine}/agreement/respond", json={"action": "request_changes", "comments": "Extend by two weeks"}).status_code, 200)
        self.assertEqual(ministry.post(f"{gov}/agreement/send", json={"agreement": agreement(endDate="2026-12-15")}).status_code, 200)
        accept = {"action": "accept", "signatoryName": "Priya", "designation": "CEO", "confirm": True}
        self.assertEqual(startup.post(f"{mine}/agreement/respond", json={**accept, "version": 1}).status_code, 409)
        self.assertEqual(startup.post(f"{mine}/agreement/respond", json={**accept, "version": 2}).status_code, 200)

        # Readiness gate
        self.assertEqual(ministry.post(f"{gov}/go-live").status_code, 409)
        self.assertEqual(ministry.post(f"{gov}/readiness", json={"item": "security_review", "done": True}).status_code, 400)
        for item in pe.readiness_items("Pilot"):
            self.assertEqual(ministry.post(f"{gov}/readiness", json={"item": item["key"], "done": True, "evidence": "Ref 123"}).status_code, 200)
        self.assertEqual(ministry.post(f"{gov}/go-live").status_code, 200)

        # Startup report with readings, a claim and a critical incident
        report = {
            "summary": "First fortnight",
            "measurements": [
                {"kpiId": "KPI-1", "value": 30, "date": "2026-10-10", "evidence": "CRM export"},
                {"kpiId": "KPI-2", "value": 78, "date": "2026-10-10", "evidence": "Survey n=210"},
            ],
            "milestoneClaims": [{"milestoneId": "MS-1", "evidence": "Deployed on 18 Sep"}],
            "incidents": [{"severity": "Critical", "description": "Data sync outage 6h"}],
        }
        self.assertEqual(startup.post(f"{mine}/reports", json=report).status_code, 200)
        state = ministry.get(gov).get_json()
        self.assertTrue(state["health"]["suspension_recommended"])
        self.assertIsNone(state["health"]["current_attainment"])  # nothing verified yet

        # Suspend, resume blocked by open critical incident, resolve, resume
        self.assertEqual(ministry.post(f"{gov}/suspend", json={"reason": "Outage"}).status_code, 200)
        self.assertEqual(ministry.post(f"{gov}/resume", json={"reason": "Fixed"}).status_code, 409)
        self.assertEqual(ministry.post(f"{gov}/incidents/INC-001/resolve", json={"resolution": "Failover added"}).status_code, 200)
        self.assertEqual(ministry.post(f"{gov}/resume", json={"reason": "Fixed and verified"}).status_code, 200)

        # Verification and payments
        self.assertEqual(ministry.post(f"{gov}/milestones/MS-1/payment", json={"reference": "SO-1"}).status_code, 409)
        self.assertEqual(ministry.post(f"{gov}/measurements/MEA-0001", json={"decision": "rejected"}).status_code, 400)
        for measurement_id in ("MEA-0001", "MEA-0002"):
            self.assertEqual(ministry.post(f"{gov}/measurements/{measurement_id}", json={"decision": "verified"}).status_code, 200)
        self.assertEqual(ministry.post(f"{gov}/milestones/MS-1/verify", json={"decision": "verified"}).status_code, 200)
        paid = ministry.post(f"{gov}/milestones/MS-1/payment", json={"reference": "SO-1"})
        self.assertEqual(paid.status_code, 200)
        self.assertIn("300,000", paid.get_json()["message"])
        self.assertEqual(ministry.post(f"{gov}/milestones/MS-1/payment", json={"reference": "SO-1"}).status_code, 409)

        # Review and board decision
        self.assertEqual(ministry.post(f"{gov}/decision", json={"decision": "scale", "rationale": "x"}).status_code, 409)
        self.assertEqual(ministry.post(f"{gov}/review", json={}).status_code, 200)
        self.assertEqual(startup.post(f"{mine}/reports", json=report).status_code, 409)
        state = ministry.get(gov).get_json()
        recommended = state["scorecard"]["recommendation"]
        self.assertEqual(recommended, "extend")  # 89% attained but milestones not yet verified
        self.assertEqual(ministry.post(f"{gov}/decision", json={"decision": "scale", "rationale": "Strong results"}).status_code, 400)
        extended = ministry.post(f"{gov}/decision", json={"decision": "extend", "rationale": "Finish milestones", "newEndDate": "2027-02-01"})
        self.assertEqual(extended.status_code, 200)
        self.assertEqual(extended.get_json()["stage"], "active")
        ministry.post(f"{gov}/review", json={})
        closed = ministry.post(f"{gov}/decision", json={"decision": "procurement", "rationale": "Tender", "overrideReason": "Cabinet directive to procure"})
        self.assertEqual(closed.get_json()["stage"], "procurement")
        self.assertEqual(ministry.get("/sandbox-pilots").status_code, 200)
        self.assertIn(b"Open pilot", startup.get("/startup-portal").data)


def load_tests(loader, tests, pattern):
    suite = unittest.TestSuite()
    suite.addTests(loader.loadTestsFromTestCase(PilotEngineTests))
    for name in loader.getTestCaseNames(PilotRouteTests):
        if name.startswith("test_pilot") or name == "test_full_pilot_lifecycle":
            suite.addTest(PilotRouteTests(name))
    return suite
